/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto.de.unidad;

import java.util.Scanner;

/**
 *
 * @author Marvin
 */
public class ProyectoDeUnidad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Juego piedra-papel-tijera");
		Scanner teclado = new Scanner(System.in);

		int seleccionCompu = (int)(Math.random() * 3) + 1;
		System.out.println("La computadora ya a escogido...");

		System.out.print("selecciona uno 1=Piedra, 2=Papel, 3=Tijera : ");
		int seleccionUsuario = teclado.nextInt();

		System.out.print("La computadora habia escogido: ");
		switch (seleccionCompu) {
                     case 1 :
				System.out.println("Piedra");
				switch (seleccionUsuario) {
					case 1: System.out.println("Empate "); break;
					case 2: System.out.println("Usted es el ganador!"); break;
					case 3: System.out.println("La computadora gana"); break;
				}
				break;

			case 2:
				System.out.println("Papel");
				switch (seleccionUsuario) {
					case 1: System.out.println("La computadora gana"); break;
					case 2: System.out.println("Empate"); break;
					case 3: System.out.println("Usted es el ganador "); break;
				}
				break;

			case 3:
				System.out.println("Tijera");
				switch (seleccionUsuario){
					case 1: System.out.println("Usted gana "); break;
					case 2: System.out.println("¡La computadora gana!"); break;
					case 3: System.out.println("Empate"); break;
				}
				break;
                    
                }
                    System.out.println("");
                    System.out.println("el juego Matematico de matrizes");
        int[][] JuegoMatematico = new int[3][3];
        JuegoMatematico[0][0] = 5;
        JuegoMatematico[0][1] = 6;
        JuegoMatematico[0][2] = 8;
        JuegoMatematico[1][0] = 12;
        JuegoMatematico[1][1] = 10;
        JuegoMatematico[1][2] = 2; 
        JuegoMatematico[2][0] = 450;
        JuegoMatematico[2][1] = 250;
        JuegoMatematico[2][2] = 4;
        
        for(int i = 0; i < 3; i++){
        int suma = 0;
        for (int j = 0; j < JuegoMatematico[i].length; j++) {
            System.out.printf("%d ", JuegoMatematico[i][j]);
            suma += JuegoMatematico[i][j];
        }
        System.out.printf("= %d\n", suma);
            }
    }
    
}
